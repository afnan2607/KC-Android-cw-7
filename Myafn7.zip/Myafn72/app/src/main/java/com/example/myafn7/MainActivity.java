package com.example.myafn7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Items> itemsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Items cheese = new Items("cheese",R.drawable.cheese);
        Items chocolate = new Items("chocolate",R.drawable.chocolate);
        Items coffee = new Items("cofee",R.drawable.coffee);
        Items donut = new ItemsAdapter("donut",R.drawable.donut);
        Items honey = new Items("honey",R.drawable.honey);
        Items fries = new ItemsAdapter("fries",R.drawable.fries);

        itemsList.add(cheese);
        itemsList.add(chocolate);
        itemsList.add(coffee);
        itemsList.add(donut);
        itemsList.add(honey);
        itemsList.add(fries);

        ItemsAdapter itemsAdapter =new ItemsAdapter(this,0,itemsList);
        ListView listView = findViewById(R.id.listView);

        listView.setAdapter(itemsAdapter);



    }


}